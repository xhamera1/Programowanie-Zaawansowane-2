﻿namespace Lab08;

public class CsvReadResult
{
    public List<string> Headers { get; set; } = new List<string>();
    public List<List<string>> Data { get; set; } = new List<List<string>>();
}